using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AimerScript : MonoBehaviour
{
    private PlayerBallController ballCtrl;
    private float inputU, inputV;
    public float sensitivity = 6;

    void Awake()
    {
        //To assign values to our aim variable. Aim variable not used in current version of PlayerBallController script.
        ballCtrl = GetComponentInParent<PlayerBallController>();
    }
    
    void Update()
    {
        ProcessInputs();
        Debug.DrawRay(transform.position, transform.forward * 10, Color.magenta);
    }

    void FixedUpdate()
    {
        Vector3 input = SquareToCircle(new Vector3(inputU, this.transform.forward.y, inputV));

        float stepSmoothing = sensitivity * Time.fixedDeltaTime;
        
        // Should take the local rotation/direction and rotate it towards whatever the input vector/direction is
        Vector3 newDirection = Vector3.RotateTowards(this.transform.forward, input, stepSmoothing, 0.0f);

        // Calculate a rotation a step closer to the target and applies rotation to this object (local rotation)
        this.transform.rotation = Quaternion.LookRotation(newDirection, Vector3.up);
        //transform.rotation = Quaternion.RotateTowards(transform.localRotation, input, stepSmoothing);

        //For now the aiming is handled in this script and added onto a child object instead of directly to the main game object
        ballCtrl.aim = transform.forward; //Returns in world space coordinates
    }

    Vector3 SquareToCircle(Vector3 input)
    {
        //Makes sure that the input returns with equal force in any direction
        return (input.sqrMagnitude >= 1f) ? input.normalized : input;
    }

    private void ProcessInputs()
    {
        inputU = Input.GetAxis("Horizontal");
        inputV = Input.GetAxis("Vertical");
    }
}
