﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using RootMotion.Dynamics;

namespace RootMotion.Demos
{

    [CustomEditor(typeof(PuppetMasterPropMelee))]
    public class PuppetMasterPropMeleeInspector : PuppetMasterPropInspector
    {

        protected override void OnSceneGUI()
        {
            base.OnSceneGUI();
        }
    }
}
